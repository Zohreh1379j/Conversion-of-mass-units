function check(){
	var inp = document.getElementById("inp").value;
	var sel = document.getElementById("sel").value;
	
	if(inp != ""){
		if(sel != 0){
			//تبدیل تن به کیلو
			if(sel == 1){
				var res = parseInt(inp) * parseInt(1000);
				document.getElementById("num").innerHTML = res;
				document.getElementById("wi").innerHTML = "کیلو گرم";
				
			//تبدیل تن به گرم			
			}else if(sel == 2){
				var res = parseInt(inp) * parseInt(1000000);
				document.getElementById("num").innerHTML = res;
				document.getElementById("wi").innerHTML = "گرم";
				
			//تبدیل کیلو به گرم	
			}else if(sel == 3){
				 
				var res = parseInt(inp) * parseInt(1000);
				document.getElementById("num").innerHTML = res;
				document.getElementById("wi").innerHTML = "گرم";
			}
		}else{
			alert("نوع تبدیل  را وارد نمایید");
		}
	}else{
		alert("وزن  را وارد نمایید");
	}
	
}